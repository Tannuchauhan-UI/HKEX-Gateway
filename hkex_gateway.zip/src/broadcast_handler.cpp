#include "../include/broadcast_handler.hpp"
#include "../include/logger.hpp"
#include "../external/omnet/include/omnet_common.h"
#include <iostream>

BroadcastHandler::BroadcastHandler() = default;

BroadcastHandler::~BroadcastHandler() {
    // Unsubscribe from all symbols
    for (const auto& symbol : subscribed_symbols_) {
        omni_unsubscribe(symbol.c_str());
    }
}

bool BroadcastHandler::subscribe(const std::string& symbol) {
    std::lock_guard<std::mutex> lock(market_data_mutex_);
    
    try {
        if (subscribed_symbols_.find(symbol) != subscribed_symbols_.end()) {
            Logger::getInstance().log(LogLevel::WARNING, "Already subscribed to symbol: " + symbol);
            return true;
        }

        if (omni_subscribe(symbol.c_str()) != 0) {
            Logger::getInstance().logError("Failed to subscribe to symbol: " + symbol);
            return false;
        }

        subscribed_symbols_.insert(symbol);
        market_data_[symbol] = std::make_shared<MarketData>();
        market_data_[symbol]->symbol = symbol;

        Logger::getInstance().log(LogLevel::INFO, "Subscribed to symbol: " + symbol);
        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error subscribing to symbol: ") + e.what());
        return false;
    }
}

bool BroadcastHandler::unsubscribe(const std::string& symbol) {
    std::lock_guard<std::mutex> lock(market_data_mutex_);
    
    try {
        if (subscribed_symbols_.find(symbol) == subscribed_symbols_.end()) {
            return true;
        }

        if (omni_unsubscribe(symbol.c_str()) != 0) {
            Logger::getInstance().logError("Failed to unsubscribe from symbol: " + symbol);
            return false;
        }

        subscribed_symbols_.erase(symbol);
        market_data_.erase(symbol);

        Logger::getInstance().log(LogLevel::INFO, "Unsubscribed from symbol: " + symbol);
        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error unsubscribing from symbol: ") + e.what());
        return false;
    }
}

bool BroadcastHandler::isSubscribed(const std::string& symbol) const {
    std::lock_guard<std::mutex> lock(market_data_mutex_);
    return subscribed_symbols_.find(symbol) != subscribed_symbols_.end();
}

void BroadcastHandler::handleMarketData(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(market_data_mutex_);
    
    try {
        std::string symbol(msg->symbol);
        auto it = market_data_.find(symbol);
        if (it == market_data_.end()) {
            Logger::getInstance().logError("Received market data for unsubscribed symbol: " + symbol);
            return;
        }

        processMarketData(msg);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling market data: ") + e.what());
    }
}

void BroadcastHandler::handleTradingStatus(const omni_message* msg) {
    if (!msg) return;
    
    try {
        std::string symbol(msg->symbol);
        std::string status(msg->text);
        
        notifyStatusCallbacks(symbol, status);
        Logger::getInstance().log(LogLevel::INFO, "Trading status update - Symbol: " + symbol + ", Status: " + status);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling trading status: ") + e.what());
    }
}

void BroadcastHandler::handleReferenceData(const omni_message* msg) {
    if (!msg) return;
    
    try {
        std::string symbol(msg->symbol);
        // Process reference data based on specific message format
        Logger::getInstance().log(LogLevel::INFO, "Reference data received for symbol: " + symbol);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling reference data: ") + e.what());
    }
}

MarketData BroadcastHandler::getMarketData(const std::string& symbol) const {
    std::lock_guard<std::mutex> lock(market_data_mutex_);
    
    auto it = market_data_.find(symbol);
    if (it == market_data_.end()) {
        throw std::runtime_error("No market data available for symbol: " + symbol);
    }
    
    return *(it->second);
}

std::vector<std::string> BroadcastHandler::getSubscribedSymbols() const {
    std::lock_guard<std::mutex> lock(market_data_mutex_);
    return std::vector<std::string>(subscribed_symbols_.begin(), subscribed_symbols_.end());
}

void BroadcastHandler::registerMarketDataCallback(MarketDataCallback callback) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    market_data_callbacks_.push_back(std::move(callback));
}

void BroadcastHandler::registerStatusCallback(StatusCallback callback) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    status_callbacks_.push_back(std::move(callback));
}

void BroadcastHandler::processMarketData(const omni_message* msg) {
    std::string symbol(msg->symbol);
    auto& data = market_data_[symbol];
    
    // Update market data based on message type
    data->symbol = symbol;
    data->last_price = msg->price;
    data->last_size = msg->quantity;
    data->timestamp = std::chrono::system_clock::now();
    
    // Notify callbacks
    notifyMarketDataCallbacks(*data);
    
    // Log market data update
    std::stringstream ss;
    ss << "Market data update - Symbol: " << symbol
       << ", Price: " << data->last_price
       << ", Size: " << data->last_size;
    Logger::getInstance().log(LogLevel::DEBUG, ss.str());
}

void BroadcastHandler::notifyMarketDataCallbacks(const MarketData& data) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    for (const auto& callback : market_data_callbacks_) {
        try {
            callback(data);
        }
        catch (const std::exception& e) {
            Logger::getInstance().logError(std::string("Error in market data callback: ") + e.what());
        }
    }
}

void BroadcastHandler::notifyStatusCallbacks(const std::string& symbol, const std::string& status) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    for (const auto& callback : status_callbacks_) {
        try {
            callback(symbol, status);
        }
        catch (const std::exception& e) {
            Logger::getInstance().logError(std::string("Error in status callback: ") + e.what());
        }
    }
}

bool BroadcastHandler::handleOMNIAPINotFound() {
    // Handle the case when broadcast buffer is empty
    return true;
} 