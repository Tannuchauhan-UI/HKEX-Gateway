#include "../include/gateway.hpp"
#include "../include/session_manager.hpp"
#include "../include/order_manager.hpp"
#include "../include/broadcast_handler.hpp"
#include "../include/trade_manager.hpp"
#include "../include/logger.hpp"

#include <fstream>
#include <iostream>
#include <json/json.h>

HKEXGateway& HKEXGateway::getInstance() {
    static HKEXGateway instance;
    return instance;
}

HKEXGateway::HKEXGateway() = default;

HKEXGateway::~HKEXGateway() {
    stop();
}

bool HKEXGateway::isConnected() const {
    return is_connected_;
}

bool HKEXGateway::isRunning() const {
    return is_running_;
}

bool HKEXGateway::initialize(const std::string& config_file) {
    try {
        // Initialize logger first
        if (!initializeLogger()) {
            return false;
        }

        // Read configuration
        std::ifstream config_stream(config_file);
        if (!config_stream.is_open()) {
            Logger::getInstance().logError("Failed to open config file: " + config_file);
            return false;
        }

        Json::Value config;
        config_stream >> config;

        // Initialize components
        if (!initializeSessionManager() ||
            !initializeOrderManager() ||
            !initializeBroadcastHandler() ||
            !initializeTradeManager()) {
            return false;
        }

        Logger::getInstance().log(LogLevel::INFO, "Gateway initialized successfully");
        return true;
    }
    catch (const std::exception& e) {
        handleError("Initialization failed: " + std::string(e.what()), true);
        return false;
    }
}

bool HKEXGateway::start() {
    if (is_running_) {
        Logger::getInstance().log(LogLevel::WARNING, "Gateway already running");
        return false;
    }

    try {
        is_running_ = true;
        message_thread_ = std::make_unique<std::thread>(&HKEXGateway::processMessages, this);
        Logger::getInstance().log(LogLevel::INFO, "Gateway started");
        return true;
    }
    catch (const std::exception& e) {
        handleError("Failed to start gateway: " + std::string(e.what()));
        is_running_ = false;
        return false;
    }
}

void HKEXGateway::stop() {
    if (!is_running_) {
        return;
    }

    is_running_ = false;
    if (message_thread_ && message_thread_->joinable()) {
        message_thread_->join();
    }

    // Clean up components
    if (session_manager_) {
        session_manager_->disconnect();
    }

    Logger::getInstance().log(LogLevel::INFO, "Gateway stopped");
}

bool HKEXGateway::initializeLogger() {
    try {
        Logger::getInstance().initialize("gateway.log", "error.log", LogLevel::INFO);
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "Failed to initialize logger: " << e.what() << std::endl;
        return false;
    }
}

bool HKEXGateway::initializeSessionManager() {
    try {
        session_manager_ = std::make_unique<SessionManager>();
        return true;
    }
    catch (const std::exception& e) {
        handleError("Failed to initialize session manager: " + std::string(e.what()));
        return false;
    }
}

bool HKEXGateway::initializeOrderManager() {
    try {
        order_manager_ = std::make_unique<OrderManager>();
        return true;
    }
    catch (const std::exception& e) {
        handleError("Failed to initialize order manager: " + std::string(e.what()));
        return false;
    }
}

bool HKEXGateway::initializeBroadcastHandler() {
    try {
        broadcast_handler_ = std::make_unique<BroadcastHandler>();
        return true;
    }
    catch (const std::exception& e) {
        handleError("Failed to initialize broadcast handler: " + std::string(e.what()));
        return false;
    }
}

bool HKEXGateway::initializeTradeManager() {
    try {
        trade_manager_ = std::make_unique<TradeManager>();
        return true;
    }
    catch (const std::exception& e) {
        handleError("Failed to initialize trade manager: " + std::string(e.what()));
        return false;
    }
}

void HKEXGateway::processMessages() {
    while (is_running_) {
        try {
            // Process incoming messages from the exchange
            // This will be implemented based on the specific OMnet API requirements
        }
        catch (const std::exception& e) {
            handleError("Error processing messages: " + std::string(e.what()));
        }
    }
}

void HKEXGateway::handleError(const std::string& error, bool fatal) {
    Logger::getInstance().logError(error);
    if (fatal) {
        stop();
    }
} 