#include "ErrorHandler.hpp"
#include <sstream>

ErrorHandler& ErrorHandler::getInstance() {
    static ErrorHandler instance;
    return instance;
}

void ErrorHandler::handleError(int errorCode, const std::string& context) {
    std::string errorMsg = getErrorMessage(errorCode);
    std::stringstream ss;
    ss << "Error in " << context << ": " << errorMsg << " (code: " << errorCode << ")";
    logError(ss.str());
    
    if (errorCode < 0) {
        throw OMnetError(ss.str());
    }
}

void ErrorHandler::handleOMnetError(int omnetReturnCode, const std::string& context) {
    if (omnetReturnCode != OMNIAPI_SUCCESS) {
        handleError(omnetReturnCode, context);
    }
}

std::string ErrorHandler::getErrorMessage(int errorCode) {
    switch (errorCode) {
        case OMNIAPI_SUCCESS:
            return "Success";
        case OMNIAPI_NOT_FOUND:
            return "Not found";
        case OMNIAPI_INVALID_SESSION:
            return "Invalid session";
        case OMNIAPI_CONNECTION_ERROR:
            return "Connection error";
        default:
            return "Unknown error";
    }
}

void ErrorHandler::logError(const std::string& message) {
    Logger::getInstance().log(Logger::LogLevel::ERROR, message);
} 