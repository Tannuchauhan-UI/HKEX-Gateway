#include "../include/trade_manager.hpp"
#include "../include/omnet_common.hpp"
#include "../include/logger.hpp"
#include <sstream>
#include <iomanip>
#include <chrono>

TradeManager::TradeManager() = default;

TradeManager::~TradeManager() = default;

void TradeManager::handleTradeConfirm(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    try {
        // Create trade object
        auto trade = std::make_shared<Trade>();
        trade->trade_id = generateTradeId();
        trade->order_id = msg->clorder_id;
        trade->symbol = msg->symbol;
        trade->price = msg->price;
        trade->quantity = msg->quantity;
        trade->is_buy = (msg->side == 1);
        trade->trade_time = std::chrono::system_clock::now();

        // Store trade
        trades_[trade->trade_id] = trade;
        order_trades_[trade->order_id].push_back(trade->trade_id);
        symbol_trades_[trade->symbol].push_back(trade->trade_id);

        // Notify callbacks
        notifyTradeCallbacks(*trade);
        notifyStatusCallbacks(trade->trade_id, "CONFIRMED");

        // Log trade
        std::stringstream ss;
        ss << "Trade confirmed - ID: " << trade->trade_id
           << ", Order: " << trade->order_id
           << ", Symbol: " << trade->symbol
           << ", Price: " << trade->price
           << ", Quantity: " << trade->quantity
           << ", Side: " << (trade->is_buy ? "Buy" : "Sell");
        Logger::getInstance().log(LogLevel::INFO, ss.str());
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling trade confirm: ") + e.what());
    }
}

void TradeManager::handleTradeReject(const omni_message* msg) {
    if (!msg) return;
    
    try {
        std::string order_id(msg->clorder_id);
        std::string reason(msg->text);
        
        notifyStatusCallbacks(order_id, "REJECTED: " + reason);
        Logger::getInstance().logError("Trade rejected - Order: " + order_id + ", Reason: " + reason);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling trade reject: ") + e.what());
    }
}

void TradeManager::handleTradeCancel(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    try {
        std::string trade_id(msg->trade_id);
        auto it = trades_.find(trade_id);
        if (it == trades_.end()) {
            Logger::getInstance().logError("Received cancel for unknown trade: " + trade_id);
            return;
        }

        // Notify callbacks
        notifyStatusCallbacks(trade_id, "CANCELLED");

        Logger::getInstance().log(LogLevel::INFO, "Trade cancelled: " + trade_id);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling trade cancel: ") + e.what());
    }
}

void TradeManager::handleTradeAmend(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    try {
        std::string trade_id(msg->trade_id);
        auto trade_it = trades_.find(trade_id);
        
        if (trade_it != trades_.end()) {
            auto& trade = trade_it->second;
            trade->price = msg->price;
            trade->quantity = msg->quantity;
            trade->status = TradeStatus::AMENDED;
            
            // Log amendment
            std::stringstream ss;
            ss << "Trade amended - ID: " << trade_id
               << ", New Price: " << trade->price
               << ", New Quantity: " << trade->quantity;
            Logger::getInstance().logTrade(ss.str());
            
            // Notify callbacks
            notifyTradeCallbacks(*trade);
        }
        
    } catch (const std::exception& e) {
        Logger::getInstance().logError("Error handling trade amendment", e.what());
    }
}

void TradeManager::handleStatusUpdate(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    try {
        std::string trade_id(msg->trade_id);
        std::string status_text(msg->text);
        
        // Log status update
        Logger::getInstance().logTrade("Trade status update - ID: " + trade_id + ", Status: " + status_text);
        
        // Notify callbacks
        notifyStatusCallbacks(trade_id, status_text);
        
    } catch (const std::exception& e) {
        Logger::getInstance().logError("Error handling status update", e.what());
    }
}

Trade TradeManager::getTrade(const std::string& trade_id) const {
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    auto it = trades_.find(trade_id);
    if (it == trades_.end()) {
        throw std::runtime_error("Trade not found: " + trade_id);
    }
    
    return *(it->second);
}

std::vector<Trade> TradeManager::getTradesByOrder(const std::string& order_id) const {
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    std::vector<Trade> result;
    auto it = order_trades_.find(order_id);
    if (it != order_trades_.end()) {
        for (const auto& trade_id : it->second) {
            auto trade_it = trades_.find(trade_id);
            if (trade_it != trades_.end()) {
                result.push_back(*(trade_it->second));
            }
        }
    }
    
    return result;
}

std::vector<Trade> TradeManager::getTradesBySymbol(const std::string& symbol) const {
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    std::vector<Trade> result;
    auto it = symbol_trades_.find(symbol);
    if (it != symbol_trades_.end()) {
        for (const auto& trade_id : it->second) {
            auto trade_it = trades_.find(trade_id);
            if (trade_it != trades_.end()) {
                result.push_back(*(trade_it->second));
            }
        }
    }
    
    return result;
}

std::vector<Trade> TradeManager::getTodayTrades() const {
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    auto today = std::chrono::system_clock::now();
    auto today_midnight = std::chrono::system_clock::from_time_t(
        std::chrono::system_clock::to_time_t(today) - (std::chrono::system_clock::to_time_t(today) % 86400)
    );
    
    std::vector<Trade> result;
    for (const auto& pair : trades_) {
        if (pair.second->trade_time >= today_midnight) {
            result.push_back(*(pair.second));
        }
    }
    
    return result;
}

void TradeManager::processPendingTrades() {
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    while (!pending_trades_.empty()) {
        auto trade = pending_trades_.front();
        pending_trades_.pop();
        
        try {
            // Process the trade
            notifyTradeCallbacks(*trade);
            Logger::getInstance().logTrade("Processed pending trade - ID: " + trade->trade_id);
        } catch (const std::exception& e) {
            Logger::getInstance().logError("Error processing pending trade", e.what());
            // Re-queue the trade for later processing
            pending_trades_.push(trade);
        }
    }
}

void TradeManager::reconcileTrades() {
    std::lock_guard<std::mutex> lock(trade_mutex_);
    
    try {
        // Request trade reconciliation from exchange
        // Implementation depends on exchange-specific message format
        Logger::getInstance().log(LogLevel::INFO, "Starting trade reconciliation");
        
        // Process reconciliation response
        // Implementation depends on exchange-specific response format
        
    } catch (const std::exception& e) {
        Logger::getInstance().logError("Error during trade reconciliation", e.what());
    }
}

void TradeManager::registerTradeCallback(TradeCallback callback) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    trade_callbacks_.push_back(std::move(callback));
}

void TradeManager::registerStatusCallback(StatusCallback callback) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    status_callbacks_.push_back(std::move(callback));
}

void TradeManager::notifyTradeCallbacks(const Trade& trade) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    for (const auto& callback : trade_callbacks_) {
        try {
            callback(trade);
        }
        catch (const std::exception& e) {
            Logger::getInstance().logError(std::string("Error in trade callback: ") + e.what());
        }
    }
}

void TradeManager::notifyStatusCallbacks(const std::string& trade_id, const std::string& status) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    for (const auto& callback : status_callbacks_) {
        try {
            callback(trade_id, status);
        }
        catch (const std::exception& e) {
            Logger::getInstance().logError(std::string("Error in status callback: ") + e.what());
        }
    }
}

std::string TradeManager::generateTradeId() {
    auto now = std::chrono::system_clock::now();
    auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()
    );
    
    std::stringstream ss;
    ss << "TRD" << std::setfill('0') << std::setw(14) << now_ms.count();
    return ss.str();
} 