#include "HKEXGateway.hpp"
#include "Logger.hpp"
#include <iostream>
#include <string>
#include <csignal>

// Global gateway instance for signal handling
HKEXGateway* g_gateway = nullptr;

// Signal handler for graceful shutdown
void signalHandler(int signum) {
    if (g_gateway) {
        std::cout << "\nReceived signal " << signum << ". Shutting down..." << std::endl;
        g_gateway->stop();
    }
}

// Callback for order status updates
void orderStatusCallback(const OrderDetails& order) {
    std::cout << "Order Status Update - ID: " << order.orderId 
              << ", Status: " << order.status << std::endl;
}

// Callback for trade updates
void tradeCallback(const TradeDetails& trade) {
    std::cout << "Trade Update - ID: " << trade.tradeId 
              << ", OrderID: " << trade.orderId 
              << ", Price: " << trade.price 
              << ", Quantity: " << trade.quantity << std::endl;
}

// Callback for market data updates
void marketDataCallback(const MarketData& data) {
    std::cout << "Market Data Update - Symbol: " << data.symbol 
              << ", Last: " << data.lastPrice 
              << ", Bid: " << data.bid 
              << ", Ask: " << data.ask << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <config_file>" << std::endl;
        return 1;
    }

    try {
        // Set up signal handling
        signal(SIGINT, signalHandler);
        signal(SIGTERM, signalHandler);

        // Initialize logger
        Logger::getInstance().setLogFile("gateway.log");
        Logger::getInstance().log(Logger::LogLevel::INFO, "Starting HKEX Gateway...");

        // Get gateway instance and store in global variable for signal handling
        g_gateway = &HKEXGateway::getInstance();

        // Initialize gateway with config file
        if (!g_gateway->initialize(argv[1])) {
            std::cerr << "Failed to initialize gateway" << std::endl;
            return 1;
        }

        // Register callbacks
        g_gateway->setOrderStatusCallback(orderStatusCallback);
        g_gateway->setTradeCallback(tradeCallback);
        g_gateway->setMarketDataCallback(marketDataCallback);

        // Start the gateway
        if (!g_gateway->start()) {
            std::cerr << "Failed to start gateway" << std::endl;
            return 1;
        }

        // Wait for signal to stop
        std::cout << "Gateway is running. Press Ctrl+C to stop." << std::endl;
        while (g_gateway->isConnected()) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }

        return 0;
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
} 