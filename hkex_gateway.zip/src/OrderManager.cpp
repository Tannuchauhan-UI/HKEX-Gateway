#include "OrderManager.hpp"
#include "SessionHandler.hpp"
#include "omniapi.h"
#include "omni_inttypes.h"
#include <sstream>

OrderManager& OrderManager::getInstance() {
    static OrderManager instance;
    return instance;
}

bool OrderManager::submitOrder(const OrderDetails& order, std::string& orderId) {
    if (!validateOrder(order)) {
        return false;
    }

    // Create a new message for order submission
    omniapi_message_t* message = nullptr;
    int result = omniapi_create_message(&message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to create order message");
        return false;
    }

    // Set message type to MO31 (Order Entry)
    // Note: Actual message population would depend on the specific OMnet API message structure
    // This is a simplified version
    result = omniapi_tx_ext(SessionHandler::getInstance().getSession(), message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to submit order");
        omniapi_free_message(message);
        return false;
    }

    // Get order ID from response
    // Note: Actual order ID extraction would depend on the specific OMnet API message structure
    orderId = "ORD" + std::to_string(std::rand());  // Placeholder
    
    // Store order details
    orders[orderId] = std::make_shared<OrderDetails>(order);
    orders[orderId]->status = "PENDING";

    Logger::getInstance().log(Logger::LogLevel::INFO, 
        "Order submitted - Symbol: " + order.symbol + 
        ", Side: " + order.side + 
        ", Quantity: " + std::to_string(order.quantity) +
        ", Price: " + std::to_string(order.price));

    omniapi_free_message(message);
    return true;
}

bool OrderManager::modifyOrder(const std::string& orderId, const OrderDetails& newDetails) {
    auto it = orders.find(orderId);
    if (it == orders.end()) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Cannot modify order: Order ID not found - " + orderId);
        return false;
    }

    // Create a new message for order modification
    omniapi_message_t* message = nullptr;
    int result = omniapi_create_message(&message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to create modification message");
        return false;
    }

    // Set message type to MO33 (Order Alteration)
    result = omniapi_tx_ext(SessionHandler::getInstance().getSession(), message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to modify order");
        omniapi_free_message(message);
        return false;
    }

    // Update order details
    *(it->second) = newDetails;
    it->second->status = "PENDING_MODIFY";

    Logger::getInstance().log(Logger::LogLevel::INFO, 
        "Order modified - ID: " + orderId +
        ", New Quantity: " + std::to_string(newDetails.quantity) +
        ", New Price: " + std::to_string(newDetails.price));

    omniapi_free_message(message);
    return true;
}

bool OrderManager::cancelOrder(const std::string& orderId) {
    auto it = orders.find(orderId);
    if (it == orders.end()) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Cannot cancel order: Order ID not found - " + orderId);
        return false;
    }

    // Create a new message for order cancellation
    omniapi_message_t* message = nullptr;
    int result = omniapi_create_message(&message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to create cancellation message");
        return false;
    }

    // Set message type to MO34 (Order Deletion)
    result = omniapi_tx_ext(SessionHandler::getInstance().getSession(), message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to cancel order");
        omniapi_free_message(message);
        return false;
    }

    // Update order status
    it->second->status = "PENDING_CANCEL";

    Logger::getInstance().log(Logger::LogLevel::INFO, 
        "Order cancellation requested - ID: " + orderId);

    omniapi_free_message(message);
    return true;
}

bool OrderManager::getOrderStatus(const std::string& orderId, OrderDetails& details) {
    auto it = orders.find(orderId);
    if (it == orders.end()) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Order not found - ID: " + orderId);
        return false;
    }

    details = *(it->second);
    return true;
}

void OrderManager::updateOrderStatus(const std::string& orderId, const std::string& status) {
    auto it = orders.find(orderId);
    if (it != orders.end()) {
        it->second->status = status;
        Logger::getInstance().log(Logger::LogLevel::INFO, 
            "Order status updated - ID: " + orderId + ", Status: " + status);
    }
}

bool OrderManager::validateOrder(const OrderDetails& order) {
    if (order.symbol.empty()) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, "Invalid order: Empty symbol");
        return false;
    }

    if (order.side != "BUY" && order.side != "SELL") {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Invalid order: Invalid side - " + order.side);
        return false;
    }

    if (order.quantity <= 0) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Invalid order: Invalid quantity - " + std::to_string(order.quantity));
        return false;
    }

    if (order.price <= 0 && order.orderType != "MARKET") {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Invalid order: Invalid price - " + std::to_string(order.price));
        return false;
    }

    return true;
} 