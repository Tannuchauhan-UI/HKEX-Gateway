#include "../include/order_manager.hpp"
#include "../include/logger.hpp"
#include "../external/omnet/include/omnet_common.h"
#include <iostream>
#include <sstream>
#include <chrono>
#include <iomanip>

OrderManager::OrderManager() = default;

OrderManager::~OrderManager() = default;

std::string OrderManager::submitOrder(const std::string& symbol, double price, int quantity, bool is_buy) {
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        // Create order object
        auto order = std::make_shared<Order>();
        order->order_id = generateOrderId();
        order->symbol = symbol;
        order->price = price;
        order->quantity = quantity;
        order->filled_quantity = 0;
        order->is_buy = is_buy;
        order->status = OrderStatus::NEW;
        order->create_time = std::chrono::system_clock::now();
        order->update_time = order->create_time;

        // Create OMnet order message
        omni_message msg{};
        msg.type = ORDER_ACK;
        strncpy(msg.clorder_id, order->order_id.c_str(), sizeof(msg.clorder_id) - 1);
        strncpy(msg.symbol, symbol.c_str(), sizeof(msg.symbol) - 1);
        msg.price = price;
        msg.quantity = quantity;
        msg.side = is_buy ? 1 : 2;

        // Send order to exchange
        if (omni_send_order(&msg) != 0) {
            Logger::getInstance().logError("Failed to submit order: " + order->order_id);
            return "";
        }

        // Store order
        orders_[order->order_id] = order;
        symbol_orders_[symbol].push_back(order->order_id);

        // Log order submission
        std::stringstream ss;
        ss << "Order submitted - ID: " << order->order_id
           << ", Symbol: " << symbol
           << ", Price: " << price
           << ", Quantity: " << quantity
           << ", Side: " << (is_buy ? "Buy" : "Sell");
        Logger::getInstance().log(LogLevel::INFO, ss.str());

        return order->order_id;
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error submitting order: ") + e.what());
        return "";
    }
}

bool OrderManager::modifyOrder(const std::string& order_id, double new_price, int new_quantity) {
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        auto it = orders_.find(order_id);
        if (it == orders_.end()) {
            Logger::getInstance().logError("Order not found: " + order_id);
            return false;
        }

        auto& order = it->second;
        if (order->status != OrderStatus::ACCEPTED && order->status != OrderStatus::PARTIALLY_FILLED) {
            Logger::getInstance().logError("Cannot modify order in current state: " + order_id);
            return false;
        }

        // Create modification message
        omni_message msg{};
        msg.type = ORDER_ACK;
        strncpy(msg.clorder_id, order_id.c_str(), sizeof(msg.clorder_id) - 1);
        strncpy(msg.symbol, order->symbol.c_str(), sizeof(msg.symbol) - 1);
        msg.price = new_price;
        msg.quantity = new_quantity;
        msg.side = order->is_buy ? 1 : 2;

        // Send modification to exchange
        if (omni_modify_order(&msg) != 0) {
            Logger::getInstance().logError("Failed to modify order: " + order_id);
            return false;
        }

        // Update order
        order->price = new_price;
        order->quantity = new_quantity;
        order->update_time = std::chrono::system_clock::now();

        // Log modification
        std::stringstream ss;
        ss << "Order modified - ID: " << order_id
           << ", New Price: " << new_price
           << ", New Quantity: " << new_quantity;
        Logger::getInstance().log(LogLevel::INFO, ss.str());

        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error modifying order: ") + e.what());
        return false;
    }
}

bool OrderManager::cancelOrder(const std::string& order_id) {
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        auto it = orders_.find(order_id);
        if (it == orders_.end()) {
            Logger::getInstance().logError("Order not found: " + order_id);
            return false;
        }

        auto& order = it->second;
        if (order->status != OrderStatus::ACCEPTED && order->status != OrderStatus::PARTIALLY_FILLED) {
            Logger::getInstance().logError("Cannot cancel order in current state: " + order_id);
            return false;
        }

        // Create cancellation message
        omni_message msg{};
        msg.type = ORDER_ACK;
        strncpy(msg.clorder_id, order_id.c_str(), sizeof(msg.clorder_id) - 1);
        strncpy(msg.symbol, order->symbol.c_str(), sizeof(msg.symbol) - 1);

        // Send cancellation to exchange
        if (omni_cancel_order(&msg) != 0) {
            Logger::getInstance().logError("Failed to cancel order: " + order_id);
            return false;
        }

        // Update order status
        order->status = OrderStatus::CANCELLED;
        order->update_time = std::chrono::system_clock::now();

        // Log cancellation
        Logger::getInstance().log(LogLevel::INFO, "Order cancelled: " + order_id);

        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error cancelling order: ") + e.what());
        return false;
    }
}

void OrderManager::handleOrderAck(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        std::string order_id(msg->clorder_id);
        auto it = orders_.find(order_id);
        if (it == orders_.end()) {
            Logger::getInstance().logError("Received ACK for unknown order: " + order_id);
            return;
        }

        auto& order = it->second;
        order->status = OrderStatus::ACCEPTED;
        order->update_time = std::chrono::system_clock::now();

        // Notify callbacks
        notifyOrderCallbacks(*order);
        notifyStatusCallbacks(order_id, OrderStatus::ACCEPTED, "Order accepted");

        Logger::getInstance().log(LogLevel::INFO, "Order acknowledged: " + order_id);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling order ACK: ") + e.what());
    }
}

void OrderManager::handleOrderReject(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        std::string order_id(msg->clorder_id);
        auto it = orders_.find(order_id);
        if (it == orders_.end()) {
            Logger::getInstance().logError("Received reject for unknown order: " + order_id);
            return;
        }

        auto& order = it->second;
        order->status = OrderStatus::REJECTED;
        order->error_message = msg->text;
        order->update_time = std::chrono::system_clock::now();

        // Notify callbacks
        notifyOrderCallbacks(*order);
        notifyStatusCallbacks(order_id, OrderStatus::REJECTED, order->error_message);

        Logger::getInstance().logError("Order rejected: " + order_id + " - " + order->error_message);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling order reject: ") + e.what());
    }
}

void OrderManager::handleOrderFill(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        std::string order_id(msg->clorder_id);
        auto it = orders_.find(order_id);
        if (it == orders_.end()) {
            Logger::getInstance().logError("Received fill for unknown order: " + order_id);
            return;
        }

        auto& order = it->second;
        order->filled_quantity += msg->quantity;
        order->update_time = std::chrono::system_clock::now();

        if (order->filled_quantity >= order->quantity) {
            order->status = OrderStatus::FILLED;
        } else {
            order->status = OrderStatus::PARTIALLY_FILLED;
        }

        // Notify callbacks
        notifyOrderCallbacks(*order);
        notifyStatusCallbacks(order_id, order->status,
                            "Order filled: " + std::to_string(msg->quantity) + " @ " + std::to_string(msg->price));

        // Log fill
        std::stringstream ss;
        ss << "Order " << (order->status == OrderStatus::FILLED ? "filled" : "partially filled")
           << " - ID: " << order_id
           << ", Quantity: " << msg->quantity
           << ", Price: " << msg->price
           << ", Total Filled: " << order->filled_quantity;
        Logger::getInstance().log(LogLevel::INFO, ss.str());
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling order fill: ") + e.what());
    }
}

void OrderManager::handleOrderCancel(const omni_message* msg) {
    if (!msg) return;
    
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    try {
        std::string order_id(msg->clorder_id);
        auto it = orders_.find(order_id);
        if (it == orders_.end()) {
            Logger::getInstance().logError("Received cancel for unknown order: " + order_id);
            return;
        }

        auto& order = it->second;
        order->status = OrderStatus::CANCELLED;
        order->update_time = std::chrono::system_clock::now();

        // Notify callbacks
        notifyOrderCallbacks(*order);
        notifyStatusCallbacks(order_id, OrderStatus::CANCELLED, "Order cancelled");

        Logger::getInstance().log(LogLevel::INFO, "Order cancel confirmed: " + order_id);
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Error handling order cancel: ") + e.what());
    }
}

Order OrderManager::getOrder(const std::string& order_id) const {
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    auto it = orders_.find(order_id);
    if (it == orders_.end()) {
        throw std::runtime_error("Order not found: " + order_id);
    }
    
    return *(it->second);
}

std::vector<Order> OrderManager::getOrdersBySymbol(const std::string& symbol) const {
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    std::vector<Order> result;
    auto it = symbol_orders_.find(symbol);
    if (it != symbol_orders_.end()) {
        for (const auto& order_id : it->second) {
            auto order_it = orders_.find(order_id);
            if (order_it != orders_.end()) {
                result.push_back(*(order_it->second));
            }
        }
    }
    
    return result;
}

std::vector<Order> OrderManager::getActiveOrders() const {
    std::lock_guard<std::mutex> lock(order_mutex_);
    
    std::vector<Order> result;
    for (const auto& pair : orders_) {
        const auto& order = pair.second;
        if (order->status == OrderStatus::ACCEPTED || 
            order->status == OrderStatus::PARTIALLY_FILLED) {
            result.push_back(*order);
        }
    }
    
    return result;
}

void OrderManager::registerOrderCallback(OrderCallback callback) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    order_callbacks_.push_back(std::move(callback));
}

void OrderManager::registerStatusCallback(StatusCallback callback) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    status_callbacks_.push_back(std::move(callback));
}

void OrderManager::updateOrderStatus(const std::string& order_id, OrderStatus status) {
    auto it = orders_.find(order_id);
    if (it != orders_.end()) {
        it->second->status = status;
        it->second->update_time = std::chrono::system_clock::now();
    }
}

void OrderManager::notifyOrderCallbacks(const Order& order) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    for (const auto& callback : order_callbacks_) {
        try {
            callback(order);
        }
        catch (const std::exception& e) {
            Logger::getInstance().logError(std::string("Error in order callback: ") + e.what());
        }
    }
}

void OrderManager::notifyStatusCallbacks(const std::string& order_id, OrderStatus status, const std::string& message) {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    for (const auto& callback : status_callbacks_) {
        try {
            callback(order_id, status, message);
        }
        catch (const std::exception& e) {
            Logger::getInstance().logError(std::string("Error in status callback: ") + e.what());
        }
    }
}

std::string OrderManager::generateOrderId() {
    auto now = std::chrono::system_clock::now();
    auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()
    );
    
    std::stringstream ss;
    ss << "ORD" << std::setfill('0') << std::setw(14) << now_ms.count();
    return ss.str();
} 
} 