#include "HKEXGateway.hpp"
#include <fstream>
#include <json/json.h>
#include <thread>

HKEXGateway& HKEXGateway::getInstance() {
    static HKEXGateway instance;
    return instance;
}

HKEXGateway::~HKEXGateway() {
    stop();
}

bool HKEXGateway::initialize(const std::string& config_file) {
    if (!loadConfig(config_file)) {
        return false;
    }

    Logger::getInstance().log(Logger::LogLevel::INFO, "Initializing HKEX Gateway...");
    return true;
}

bool HKEXGateway::start() {
    if (running) {
        Logger::getInstance().log(Logger::LogLevel::WARNING, "Gateway already running");
        return true;
    }

    running = true;
    messageThread = std::make_unique<std::thread>(&HKEXGateway::processMessages, this);
    
    Logger::getInstance().log(Logger::LogLevel::INFO, "Gateway started");
    return true;
}

bool HKEXGateway::stop() {
    if (!running) {
        return true;
    }

    running = false;
    if (messageThread && messageThread->joinable()) {
        messageThread->join();
    }

    disconnect();
    Logger::getInstance().log(Logger::LogLevel::INFO, "Gateway stopped");
    return true;
}

bool HKEXGateway::connect(const std::string& host, int port,
                         const std::string& username, const std::string& password) {
    auto& session = SessionHandler::getInstance();
    
    if (!session.initialize(host, port)) {
        return false;
    }

    if (!session.login(username, password)) {
        return false;
    }

    Logger::getInstance().log(Logger::LogLevel::INFO, "Connected to HKEX");
    return true;
}

bool HKEXGateway::disconnect() {
    return SessionHandler::getInstance().logout();
}

bool HKEXGateway::isConnected() const {
    return SessionHandler::getInstance().isConnected();
}

bool HKEXGateway::submitOrder(const OrderDetails& order, std::string& orderId) {
    return OrderManager::getInstance().submitOrder(order, orderId);
}

bool HKEXGateway::modifyOrder(const std::string& orderId, const OrderDetails& newDetails) {
    return OrderManager::getInstance().modifyOrder(orderId, newDetails);
}

bool HKEXGateway::cancelOrder(const std::string& orderId) {
    return OrderManager::getInstance().cancelOrder(orderId);
}

bool HKEXGateway::getOrderStatus(const std::string& orderId, OrderDetails& details) {
    return OrderManager::getInstance().getOrderStatus(orderId, details);
}

bool HKEXGateway::subscribeMarketData(const std::string& symbol) {
    return MarketDataHandler::getInstance().subscribeSymbol(symbol);
}

bool HKEXGateway::unsubscribeMarketData(const std::string& symbol) {
    return MarketDataHandler::getInstance().unsubscribeSymbol(symbol);
}

bool HKEXGateway::getMarketData(const std::string& symbol, MarketData& data) {
    return MarketDataHandler::getInstance().getLastMarketData(symbol, data);
}

bool HKEXGateway::getTrade(const std::string& tradeId, TradeDetails& trade) {
    return TradeManager::getInstance().getTrade(tradeId, trade);
}

std::vector<TradeDetails> HKEXGateway::getTradesByOrder(const std::string& orderId) {
    return TradeManager::getInstance().getTradesByOrder(orderId);
}

void HKEXGateway::setOrderStatusCallback(std::function<void(const OrderDetails&)> callback) {
    orderCallback = callback;
}

void HKEXGateway::setTradeCallback(std::function<void(const TradeDetails&)> callback) {
    tradeCallback = callback;
}

void HKEXGateway::setMarketDataCallback(std::function<void(const MarketData&)> callback) {
    marketDataCallback = callback;
}

bool HKEXGateway::loadConfig(const std::string& config_file) {
    try {
        std::ifstream file(config_file);
        if (!file.is_open()) {
            Logger::getInstance().log(Logger::LogLevel::ERROR, 
                "Failed to open config file: " + config_file);
            return false;
        }

        Json::Value root;
        file >> root;

        // Initialize logger
        auto logFile = root["logging"]["log_file"].asString();
        Logger::getInstance().setLogFile(logFile);

        // Connect to HKEX
        auto host = root["connection"]["host"].asString();
        auto port = root["connection"]["port"].asInt();
        auto username = root["connection"]["username"].asString();
        auto password = root["connection"]["password"].asString();

        if (!connect(host, port, username, password)) {
            return false;
        }

        // Subscribe to market data
        const auto& symbols = root["market_data"]["symbols"];
        for (const auto& symbol : symbols) {
            subscribeMarketData(symbol.asString());
        }

        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Failed to load config: " + std::string(e.what()));
        return false;
    }
}

void HKEXGateway::processMessages() {
    Logger::getInstance().log(Logger::LogLevel::INFO, "Message processing thread started");

    while (running) {
        try {
            omniapi_message_t* message = nullptr;
            int result = omniapi_read_event_block(SessionHandler::getInstance().getSession(), message);

            if (result == OMNIAPI_SUCCESS && message != nullptr) {
                // Process the message based on its type
                int messageType;
                omniapi_get_message_type(message, &messageType);

                switch (messageType) {
                    case BO5_ORDER_BOOK:
                        // Process market data update
                        break;
                    case BO6_TRADE_INFO:
                        // Process trade update
                        break;
                    default:
                        // Handle other message types
                        break;
                }

                omniapi_free_message(message);
            }
            else if (result != OMNIAPI_NOT_FOUND) {
                ErrorHandler::getInstance().handleOMnetError(result, "Error reading message");
            }
        }
        catch (const std::exception& e) {
            Logger::getInstance().log(Logger::LogLevel::ERROR, 
                "Error in message processing: " + std::string(e.what()));
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }

    Logger::getInstance().log(Logger::LogLevel::INFO, "Message processing thread stopped");
} 