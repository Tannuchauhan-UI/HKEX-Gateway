#include "MarketDataHandler.hpp"
#include "SessionHandler.hpp"
#include "omniapi.h"
#include "omni_inttypes.h"
#include <sstream>

MarketDataHandler& MarketDataHandler::getInstance() {
    static MarketDataHandler instance;
    return instance;
}

bool MarketDataHandler::subscribeSymbol(const std::string& symbol) {
    // Create a new message for market data subscription
    omniapi_message_t* message = nullptr;
    int result = omniapi_create_message(&message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to create subscription message");
        return false;
    }

    // Set message type to BO5 (Order Book update subscription)
    result = omniapi_tx_ext(SessionHandler::getInstance().getSession(), message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to subscribe to market data");
        omniapi_free_message(message);
        return false;
    }

    Logger::getInstance().log(Logger::LogLevel::INFO, 
        "Subscribed to market data for symbol: " + symbol);

    omniapi_free_message(message);
    return true;
}

bool MarketDataHandler::unsubscribeSymbol(const std::string& symbol) {
    // Create a new message for market data unsubscription
    omniapi_message_t* message = nullptr;
    int result = omniapi_create_message(&message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to create unsubscription message");
        return false;
    }

    // Send unsubscription message
    result = omniapi_tx_ext(SessionHandler::getInstance().getSession(), message);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to unsubscribe from market data");
        omniapi_free_message(message);
        return false;
    }

    Logger::getInstance().log(Logger::LogLevel::INFO, 
        "Unsubscribed from market data for symbol: " + symbol);

    omniapi_free_message(message);
    return true;
}

void MarketDataHandler::registerCallback(const std::string& symbol, MarketDataCallback callback) {
    callbacks[symbol] = callback;
    Logger::getInstance().log(Logger::LogLevel::INFO, 
        "Registered market data callback for symbol: " + symbol);
}

void MarketDataHandler::processMarketData(const std::string& message) {
    MarketData data;
    if (!parseMarketData(message, data)) {
        return;
    }

    // Update latest data
    latestData[data.symbol] = data;

    // Notify subscribers
    notifySubscribers(data);
}

bool MarketDataHandler::getLastMarketData(const std::string& symbol, MarketData& data) {
    auto it = latestData.find(symbol);
    if (it == latestData.end()) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "No market data available for symbol: " + symbol);
        return false;
    }

    data = it->second;
    return true;
}

bool MarketDataHandler::parseMarketData(const std::string& message, MarketData& data) {
    // Note: Actual parsing would depend on the specific OMnet API message format
    // This is a simplified placeholder implementation
    try {
        // Parse message and populate data
        // For now, we just log that we received data
        Logger::getInstance().log(Logger::LogLevel::DEBUG, 
            "Received market data message: " + message);
        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Failed to parse market data: " + std::string(e.what()));
        return false;
    }
}

void MarketDataHandler::notifySubscribers(const MarketData& data) {
    auto it = callbacks.find(data.symbol);
    if (it != callbacks.end()) {
        try {
            it->second(data);
        }
        catch (const std::exception& e) {
            Logger::getInstance().log(Logger::LogLevel::ERROR, 
                "Error in market data callback: " + std::string(e.what()));
        }
    }
} 