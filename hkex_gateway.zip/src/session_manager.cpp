#include "../include/session_manager.hpp"
#include "../include/logger.hpp"
#include "../external/omnet/include/omnet_common.h"
#include <iostream>
#include <cstring>

SessionManager::SessionManager() = default;

SessionManager::~SessionManager() {
    disconnect();
}

bool SessionManager::connect(const std::string& host, int port) {
    if (is_connected_) {
        Logger::getInstance().log(LogLevel::WARNING, "Already connected");
        return false;
    }

    try {
        if (omni_init() != 0) {
            handleConnectionError("Failed to initialize OMnet API");
            return false;
        }

        if (omni_connect(host.c_str(), port) != 0) {
            handleConnectionError("Failed to connect to exchange");
            return false;
        }

        is_connected_ = true;
        if (connection_callback_) {
            connection_callback_(true);
        }

        Logger::getInstance().log(LogLevel::INFO, "Connected to exchange");
        return true;
    }
    catch (const std::exception& e) {
        handleConnectionError(std::string("Connection error: ") + e.what());
        return false;
    }
}

void SessionManager::disconnect() {
    if (!is_connected_) {
        return;
    }

    try {
        if (is_logged_in_) {
            logout();
        }

        omni_cleanup();
        is_connected_ = false;

        if (connection_callback_) {
            connection_callback_(false);
        }

        Logger::getInstance().log(LogLevel::INFO, "Disconnected from exchange");
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Disconnect error: ") + e.what());
    }
}

bool SessionManager::login(const std::string& username, const std::string& password,
                         const std::string& client_id) {
    if (!is_connected_) {
        handleLoginError("Not connected to exchange");
        return false;
    }

    if (is_logged_in_) {
        Logger::getInstance().log(LogLevel::WARNING, "Already logged in");
        return false;
    }

    try {
        omni_login_t login_data;
        strncpy(login_data.username, username.c_str(), sizeof(login_data.username) - 1);
        strncpy(login_data.password, password.c_str(), sizeof(login_data.password) - 1);
        strncpy(login_data.client_id, client_id.c_str(), sizeof(login_data.client_id) - 1);

        if (omni_login(&login_data) != 0) {
            handleLoginError("Login failed");
            return false;
        }

        username_ = username;
        client_id_ = client_id;
        session_id_ = login_data.session_id;
        is_logged_in_ = true;

        Logger::getInstance().log(LogLevel::INFO, "Successfully logged in");
        return true;
    }
    catch (const std::exception& e) {
        handleLoginError(std::string("Login error: ") + e.what());
        return false;
    }
}

bool SessionManager::logout() {
    if (!is_logged_in_) {
        return true;
    }

    try {
        if (omni_logout() != 0) {
            Logger::getInstance().logError("Logout failed");
            return false;
        }

        is_logged_in_ = false;
        session_id_.clear();

        Logger::getInstance().log(LogLevel::INFO, "Successfully logged out");
        return true;
    }
    catch (const std::exception& e) {
        Logger::getInstance().logError(std::string("Logout error: ") + e.what());
        return false;
    }
}

bool SessionManager::isConnected() const {
    return is_connected_;
}

bool SessionManager::isLoggedIn() const {
    return is_logged_in_;
}

std::string SessionManager::getSessionId() const {
    return session_id_;
}

void SessionManager::setConnectionCallback(ConnectionCallback callback) {
    connection_callback_ = std::move(callback);
}

void SessionManager::handleConnectionError(const std::string& error) {
    Logger::getInstance().logError("Connection error: " + error);
    is_connected_ = false;
    if (connection_callback_) {
        connection_callback_(false);
    }
}

void SessionManager::handleLoginError(const std::string& error) {
    Logger::getInstance().logError("Login error: " + error);
    is_logged_in_ = false;
    session_id_.clear();
}

bool SessionManager::changePassword(const std::string& old_password, const std::string& new_password) {
    if (!is_logged_in_) {
        std::cerr << "Not logged in\n";
        return false;
    }

    try {
        int result = omniapi_set_newpwd(old_password.c_str(), new_password.c_str());
        return result >= 0;
    } catch (const std::exception& e) {
        std::cerr << "Error changing password: " << e.what() << "\n";
        return false;
    }
}

bool SessionManager::validateCredentials(const std::string& username, const std::string& password) {
    return !username.empty() && !password.empty();
}

void SessionManager::setupLoginMessage(omni_login_t& login_msg, const std::string& username, const std::string& password) {
    std::memset(&login_msg, 0, sizeof(omni_login_t));
    std::strncpy(login_msg.username, username.c_str(), sizeof(login_msg.username) - 1);
    std::strncpy(login_msg.password, password.c_str(), sizeof(login_msg.password) - 1);
} 