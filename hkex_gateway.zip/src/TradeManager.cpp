#include "TradeManager.hpp"
#include "SessionHandler.hpp"
#include "omniapi.h"
#include "omni_inttypes.h"
#include <sstream>

TradeManager& TradeManager::getInstance() {
    static TradeManager instance;
    return instance;
}

void TradeManager::processTrade(const TradeDetails& trade) {
    // Store trade
    trades[trade.tradeId] = trade;
    
    // Update order-trade mapping
    orderTrades[trade.orderId].push_back(trade.tradeId);
    
    // Log trade
    logTrade(trade);
    
    // Notify about trade update
    notifyTradeUpdate(trade);
}

bool TradeManager::getTrade(const std::string& tradeId, TradeDetails& trade) {
    auto it = trades.find(tradeId);
    if (it == trades.end()) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, 
            "Trade not found - ID: " + tradeId);
        return false;
    }
    
    trade = it->second;
    return true;
}

std::vector<TradeDetails> TradeManager::getTradesByOrder(const std::string& orderId) {
    std::vector<TradeDetails> result;
    
    auto it = orderTrades.find(orderId);
    if (it != orderTrades.end()) {
        for (const auto& tradeId : it->second) {
            auto tradeIt = trades.find(tradeId);
            if (tradeIt != trades.end()) {
                result.push_back(tradeIt->second);
            }
        }
    }
    
    return result;
}

void TradeManager::updateTradeStatus(const std::string& tradeId, const std::string& status) {
    auto it = trades.find(tradeId);
    if (it != trades.end()) {
        it->second.status = status;
        logTrade(it->second);
        notifyTradeUpdate(it->second);
    }
}

std::vector<TradeDetails> TradeManager::getTradeHistory(
    const std::string& symbol, 
    const std::string& startTime,
    const std::string& endTime) {
    
    std::vector<TradeDetails> result;
    
    for (const auto& pair : trades) {
        const auto& trade = pair.second;
        if (trade.symbol == symbol && 
            trade.timestamp >= startTime && 
            trade.timestamp <= endTime) {
            result.push_back(trade);
        }
    }
    
    return result;
}

void TradeManager::logTrade(const TradeDetails& trade) {
    std::stringstream ss;
    ss << "Trade: ID=" << trade.tradeId
       << ", OrderID=" << trade.orderId
       << ", Symbol=" << trade.symbol
       << ", Side=" << trade.side
       << ", Price=" << trade.price
       << ", Quantity=" << trade.quantity
       << ", Status=" << trade.status;
    
    Logger::getInstance().log(Logger::LogLevel::INFO, ss.str());
}

void TradeManager::notifyTradeUpdate(const TradeDetails& trade) {
    // Note: In a real implementation, this would notify any registered callbacks
    // or push the update to a message queue
    Logger::getInstance().log(Logger::LogLevel::DEBUG, 
        "Trade update notification sent for trade ID: " + trade.tradeId);
} 