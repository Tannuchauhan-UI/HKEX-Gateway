#include "SessionHandler.hpp"
#include "omniapi.h"
#include <sstream>

SessionHandler& SessionHandler::getInstance() {
    static SessionHandler instance;
    return instance;
}

SessionHandler::~SessionHandler() {
    if (connected) {
        logout();
    }
    closeSession();
}

bool SessionHandler::initialize(const std::string& host, int port) {
    this->host = host;
    this->port = port;
    return createSession();
}

bool SessionHandler::login(const std::string& username, const std::string& password) {
    if (!connected) {
        Logger::getInstance().log(Logger::LogLevel::ERROR, "Cannot login: Not connected");
        return false;
    }

    this->username = username;
    int result = omniapi_login_ext(session, username.c_str(), password.c_str());
    
    if (result != OMNIAPI_SUCCESS) {
        std::stringstream ss;
        ss << "Login failed for user " << username;
        ErrorHandler::getInstance().handleOMnetError(result, ss.str());
        return false;
    }

    Logger::getInstance().log(Logger::LogLevel::INFO, "Successfully logged in");
    return true;
}

bool SessionHandler::logout() {
    if (!connected) {
        return true;
    }

    int result = omniapi_logout_ext(session);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Logout failed");
        return false;
    }

    connected = false;
    Logger::getInstance().log(Logger::LogLevel::INFO, "Successfully logged out");
    return true;
}

bool SessionHandler::isConnected() const {
    return connected;
}

bool SessionHandler::createSession() {
    int result = omniapi_create_session(&session);
    if (result != OMNIAPI_SUCCESS) {
        ErrorHandler::getInstance().handleOMnetError(result, "Failed to create session");
        return false;
    }

    connected = true;
    Logger::getInstance().log(Logger::LogLevel::INFO, "Session created successfully");
    return true;
}

void SessionHandler::closeSession() {
    if (session != nullptr) {
        // Note: The OMnet API doesn't provide a direct way to close a session
        // The session is automatically closed when the process exits
        session = nullptr;
        connected = false;
        Logger::getInstance().log(Logger::LogLevel::INFO, "Session closed");
    }
} 