#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Message types
#define TRADE_CONFIRM 1
#define TRADE_REJECT  2
#define ORDER_ACK     3
#define ORDER_FILL    4
#define MARKET_DATA   5

// Message structures
struct omni_message {
    int type;
    char clorder_id[32];
    char symbol[16];
    double price;
    int quantity;
    int side;  // 1 = Buy, 2 = Sell
    char text[256];
    char trade_id[32];
};

struct omni_login_t {
    char username[32];
    char password[32];
    char client_id[32];
    char session_id[32];
};

// API functions (these will be implemented in the actual OMnet library)
int omni_init(void);
int omni_connect(const char* host, int port);
int omni_login(const omni_login_t* login);
int omni_logout(void);
int omni_send_order(const omni_message* order);
int omni_modify_order(const omni_message* order);
int omni_cancel_order(const omni_message* order);
int omni_subscribe(const char* symbol);
int omni_unsubscribe(const char* symbol);
int omni_recv_message(omni_message* msg, int timeout_ms);
void omni_cleanup(void);

#ifdef __cplusplus
}
#endif 