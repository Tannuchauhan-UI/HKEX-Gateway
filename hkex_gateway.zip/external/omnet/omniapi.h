#ifndef OMNIAPI_H
#define OMNIAPI_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>

// Basic types
typedef void* omniapi_session_t;
typedef struct omniapi_message_t omniapi_message_t;

// Return codes
#define OMNIAPI_SUCCESS              0
#define OMNIAPI_NOT_FOUND           -1
#define OMNIAPI_INVALID_SESSION     -2
#define OMNIAPI_CONNECTION_ERROR    -3
#define OMNIAPI_NOT_FOUND_DATA      -4

// Session management functions
int omniapi_create_session(omniapi_session_t* session);
int omniapi_login_ext(omniapi_session_t session, const char* username, const char* password);
int omniapi_logout_ext(omniapi_session_t session);
int omniapi_set_newpwd_ext(omniapi_session_t session, const char* new_password);

// Transaction functions
int omniapi_tx_ext(omniapi_session_t session, omniapi_message_t* message);
int omniapi_query_ext(omniapi_session_t session, omniapi_message_t* message);

// Broadcast functions
int omniapi_read_event_block(omniapi_session_t session, omniapi_message_t* message);
int omniapi_read_event_nonblock(omniapi_session_t session, omniapi_message_t* message);

// Message handling
int omniapi_create_message(omniapi_message_t** message);
int omniapi_free_message(omniapi_message_t* message);
int omniapi_get_message_type(const omniapi_message_t* message, int* type);
int omniapi_get_message_data(const omniapi_message_t* message, void* data, size_t* size);

#ifdef __cplusplus
}
#endif

#endif // OMNIAPI_H 