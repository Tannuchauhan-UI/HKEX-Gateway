#ifndef OMNI_INTTYPES_H
#define OMNI_INTTYPES_H

#ifdef __cplusplus
extern "C" {
#endif

// Message types for order management
#define MO31_ORDER_ENTRY          31  // Order Entry
#define MO33_ORDER_ALTERATION     33  // Order Alteration
#define MO34_ORDER_DELETION       34  // Order Deletion
#define MO37_QUOTE               37  // Two-sided price quotation
#define MO96_MASS_QUOTE          96  // Mass Quote
#define DC3_ADD_COMBO            103 // Add Tailor-Made Combo

// Message types for market data
#define BO5_ORDER_BOOK           5   // Order Book update
#define MI4_QUOTE_REQUEST        4   // Quote request info
#define BI1_TRADING_STATUS       1   // Trading status broadcasts
#define BO6_TRADE_INFO          6   // Trade information

// Reference data queries
#define DQ2_SERIES              2   // Series information
#define DQ4_UNDERLYING          4   // Underlying information
#define DQ10_INSTRUMENT         10  // Instrument Class
#define DQ18_NON_TRADING_DAYS   18  // Non-trading days
#define MQ8_ORDER_QUERY         8   // Order and inactive order queries
#define MQ9_TRADE_QUERY         9   // Trade queries

// Broadcast message types
#define BROADCAST_HDR           1   // Broadcast header
#define ANSWER_HDR             2   // Answer header
#define ORDER_HDR              3   // Order header
#define ORDER_NO_ID            4   // Order number ID

#ifdef __cplusplus
}
#endif

#endif // OMNI_INTTYPES_H 