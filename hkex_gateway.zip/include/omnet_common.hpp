#pragma once

#include <cstdint>
#include <type_traits>

// OMnet API headers
extern "C" {
#include <omniapi.h>
#include <omni.h>
#include <omnifact.h>
#include <omex.h>
#include <omn_om_inttypes.h>
}

// Common OMnet message type definitions
namespace omnet {

// Message types for order operations
constexpr int MO31_ORDER_ENTRY = 31;
constexpr int MO33_ORDER_ALTERATION = 33;
constexpr int MO4_ORDER_DELETION = 4;
constexpr int MO37_TWO_SIDED_QUOTE = 37;
constexpr int MO96_MASS_QUOTE = 96;
constexpr int DC3_TAILOR_MADE_COMBO = 3;

// Message types for broadcasts
constexpr int BO5_ORDER_BOOK_UPDATE = 5;
constexpr int MI4_QUOTE_REQUEST = 4;
constexpr int BI1_TRADING_STATUS = 1;
constexpr int BO6_TRADING_STATUS = 6;
constexpr int BU7_REFERENCE_DATA = 7;
constexpr int DQ10_INSTRUMENT_CLASS = 10;
constexpr int DQ18_NON_TRADING_DAYS = 18;

// Error codes
constexpr int OMNIAPI_NOT_FOUND = -1;

// Helper functions
inline bool isOrderMessage(int msgType) {
    return msgType == MO31_ORDER_ENTRY ||
           msgType == MO33_ORDER_ALTERATION ||
           msgType == MO4_ORDER_DELETION;
}

inline bool isBroadcastMessage(int msgType) {
    return msgType == BO5_ORDER_BOOK_UPDATE ||
           msgType == MI4_QUOTE_REQUEST ||
           msgType == BI1_TRADING_STATUS ||
           msgType == BO6_TRADING_STATUS;
}

// Common OMnet API function declarations
extern "C" {
    int omniapi_read_event_block(omni_message** msg, int timeout_ms);
    void omniapi_free_message(omni_message* msg);
}

} // namespace omnet 