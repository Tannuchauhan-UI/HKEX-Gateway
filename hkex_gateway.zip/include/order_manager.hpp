#pragma once

#include <string>
#include <unordered_map>
#include <memory>
#include <functional>
#include <mutex>
#include <vector>
#include <chrono>

// Forward declarations
struct omni_message;

enum class OrderStatus {
    NEW,
    PENDING,
    ACCEPTED,
    REJECTED,
    FILLED,
    PARTIALLY_FILLED,
    CANCELLED,
    REPLACED
};

struct Order {
    std::string order_id;
    std::string symbol;
    double price;
    int quantity;
    int filled_quantity;
    bool is_buy;
    OrderStatus status;
    std::string error_message;
    std::chrono::system_clock::time_point create_time;
    std::chrono::system_clock::time_point update_time;
};

class OrderManager {
public:
    OrderManager();
    ~OrderManager();

    // Order management
    std::string submitOrder(const std::string& symbol, double price, int quantity, bool is_buy);
    bool modifyOrder(const std::string& order_id, double new_price, int new_quantity);
    bool cancelOrder(const std::string& order_id);
    
    // Order handling
    void handleOrderAck(const omni_message* msg);
    void handleOrderReject(const omni_message* msg);
    void handleOrderFill(const omni_message* msg);
    void handleOrderCancel(const omni_message* msg);
    
    // Order retrieval
    Order getOrder(const std::string& order_id) const;
    std::vector<Order> getOrdersBySymbol(const std::string& symbol) const;
    std::vector<Order> getActiveOrders() const;
    
    // Callback registration
    using OrderCallback = std::function<void(const Order&)>;
    using StatusCallback = std::function<void(const std::string&, OrderStatus, const std::string&)>;
    void registerOrderCallback(OrderCallback callback);
    void registerStatusCallback(StatusCallback callback);

private:
    // Helper functions
    void updateOrderStatus(const std::string& order_id, OrderStatus status);
    void notifyOrderCallbacks(const Order& order);
    void notifyStatusCallbacks(const std::string& order_id, OrderStatus status, const std::string& message);
    std::string generateOrderId();

    // Order storage
    std::unordered_map<std::string, std::shared_ptr<Order> > orders_;
    std::unordered_map<std::string, std::vector<std::string> > symbol_orders_; // symbol -> order_ids
    
    // Callbacks
    std::vector<OrderCallback> order_callbacks_;
    std::vector<StatusCallback> status_callbacks_;
    
    // Thread safety
    mutable std::mutex order_mutex_;
    mutable std::mutex callback_mutex_;
}; 