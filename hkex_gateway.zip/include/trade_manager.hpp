#pragma once

#include <string>
#include <unordered_map>
#include <memory>
#include <functional>
#include <mutex>
#include <vector>
#include <chrono>

// Forward declarations
struct omni_message;

struct Trade {
    std::string trade_id;
    std::string order_id;
    std::string symbol;
    double price;
    int quantity;
    bool is_buy;
    std::string counterparty;
    std::chrono::system_clock::time_point trade_time;
};

class TradeManager {
public:
    TradeManager();
    ~TradeManager();

    // Trade handling
    void handleTradeConfirm(const omni_message* msg);
    void handleTradeReject(const omni_message* msg);
    void handleTradeCancel(const omni_message* msg);
    
    // Trade retrieval
    Trade getTrade(const std::string& trade_id) const;
    std::vector<Trade> getTradesByOrder(const std::string& order_id) const;
    std::vector<Trade> getTradesBySymbol(const std::string& symbol) const;
    std::vector<Trade> getTodayTrades() const;
    
    // Callback registration
    using TradeCallback = std::function<void(const Trade&)>;
    using StatusCallback = std::function<void(const std::string&, const std::string&)>;
    void registerTradeCallback(TradeCallback callback);
    void registerStatusCallback(StatusCallback callback);

private:
    // Helper functions
    void notifyTradeCallbacks(const Trade& trade);
    void notifyStatusCallbacks(const std::string& trade_id, const std::string& status);
    std::string generateTradeId();

    // Trade storage
    std::unordered_map<std::string, std::shared_ptr<Trade> > trades_;
    std::unordered_map<std::string, std::vector<std::string> > order_trades_;
    std::unordered_map<std::string, std::vector<std::string> > symbol_trades_;
    
    // Callbacks
    std::vector<TradeCallback> trade_callbacks_;
    std::vector<StatusCallback> status_callbacks_;
    
    // Thread safety
    mutable std::mutex trade_mutex_;
    mutable std::mutex callback_mutex_;
}; 