#pragma once

#include <string>
#include <atomic>
#include <functional>

class SessionManager {
public:
    SessionManager();
    ~SessionManager();

    // Connection management
    bool connect(const std::string& host, int port);
    void disconnect();
    
    // Session management
    bool login(const std::string& username, const std::string& password,
              const std::string& client_id);
    bool logout();
    
    // Status checks
    bool isConnected() const;
    bool isLoggedIn() const;
    
    // Callback registration
    using ConnectionCallback = std::function<void(bool)>;
    void setConnectionCallback(ConnectionCallback callback);
    
    // Session info
    std::string getSessionId() const;

private:
    // Internal helpers
    void handleConnectionError(const std::string& error);
    void handleLoginError(const std::string& error);
    
    // Connection state
    std::atomic<bool> is_connected_{false};
    std::atomic<bool> is_logged_in_{false};
    
    // Session info
    std::string session_id_;
    std::string username_;
    std::string client_id_;
    
    // Callbacks
    ConnectionCallback connection_callback_;
}; 