#pragma once

#include <string>
#include <map>
#include <memory>
#include "SessionHandler.hpp"
#include "Logger.hpp"
#include "ErrorHandler.hpp"

struct OrderDetails {
    std::string symbol;
    std::string side;  // "BUY" or "SELL"
    double price;
    int quantity;
    std::string orderType;  // "LIMIT", "MARKET", etc.
    std::string timeInForce;  // "DAY", "IOC", etc.
    std::string status;
};

class OrderManager {
public:
    static OrderManager& getInstance();

    // Order management functions
    bool submitOrder(const OrderDetails& order, std::string& orderId);
    bool modifyOrder(const std::string& orderId, const OrderDetails& newDetails);
    bool cancelOrder(const std::string& orderId);
    
    // Order tracking
    bool getOrderStatus(const std::string& orderId, OrderDetails& details);
    void updateOrderStatus(const std::string& orderId, const std::string& status);

private:
    OrderManager() = default;
    ~OrderManager() = default;
    
    OrderManager(const OrderManager&) = delete;
    OrderManager& operator=(const OrderManager&) = delete;

    // Helper functions
    bool validateOrder(const OrderDetails& order);
    bool sendOrderRequest(const OrderDetails& order, const std::string& messageType);
    
    // Order storage
    std::map<std::string, std::shared_ptr<OrderDetails> > orders;
};