#pragma once

#include <string>
#include <fstream>
#include <mutex>
#include <chrono>

class Logger {
public:
    enum class LogLevel {
        DEBUG,
        INFO,
        WARNING,
        ERROR,
        CRITICAL
    };

    static Logger& getInstance();
    
    void log(LogLevel level, const std::string& message);
    void setLogFile(const std::string& filename);

private:
    Logger() = default;
    ~Logger();
    
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    std::string getCurrentTimestamp();
    std::string logLevelToString(LogLevel level);

    std::ofstream logFile;
    std::mutex logMutex;
}; 