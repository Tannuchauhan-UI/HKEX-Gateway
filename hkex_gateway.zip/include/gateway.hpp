#pragma once

#include <memory>
#include <string>
#include <atomic>
#include <thread>

// Forward declarations
class SessionManager;
class OrderManager;
class BroadcastHandler;
class TradeManager;
class Logger;

class HKEXGateway {
public:
    static HKEXGateway& getInstance();
    
    // Initialize the gateway with configuration
    bool initialize(const std::string& config_file);
    
    // Start/Stop gateway operations
    bool start();
    void stop();
    
    // Get component managers
    SessionManager* getSessionManager() const { return session_manager_.get(); }
    OrderManager* getOrderManager() const { return order_manager_.get(); }
    BroadcastHandler* getBroadcastHandler() const { return broadcast_handler_.get(); }
    TradeManager* getTradeManager() const { return trade_manager_.get(); }
    
    // Gateway status
    bool isConnected() const;
    bool isRunning() const;

private:
    HKEXGateway();
    ~HKEXGateway();
    HKEXGateway(const HKEXGateway&) = delete;
    HKEXGateway& operator=(const HKEXGateway&) = delete;

    // Component initialization
    bool initializeLogger();
    bool initializeSessionManager();
    bool initializeOrderManager();
    bool initializeBroadcastHandler();
    bool initializeTradeManager();

    // Message processing
    void processMessages();
    void handleError(const std::string& error, bool fatal = false);

    // Component managers
    std::unique_ptr<SessionManager> session_manager_;
    std::unique_ptr<OrderManager> order_manager_;
    std::unique_ptr<BroadcastHandler> broadcast_handler_;
    std::unique_ptr<TradeManager> trade_manager_;

    // Gateway state
    std::atomic<bool> is_running_{false};
    std::atomic<bool> is_connected_{false};
    std::unique_ptr<std::thread> message_thread_;
}; 