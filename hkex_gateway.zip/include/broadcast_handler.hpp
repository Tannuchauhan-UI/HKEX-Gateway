#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <mutex>
#include <functional>
#include <memory>
#include <vector>
#include <chrono>

// Forward declarations
struct omni_message;

struct MarketData {
    std::string symbol;
    double bid;
    double ask;
    int bid_size;
    int ask_size;
    double last_price;
    int last_size;
    double open;
    double high;
    double low;
    double close;
    int volume;
    std::chrono::system_clock::time_point timestamp;
};

class BroadcastHandler {
public:
    BroadcastHandler();
    ~BroadcastHandler();

    // Subscription management
    bool subscribe(const std::string& symbol);
    bool unsubscribe(const std::string& symbol);
    bool isSubscribed(const std::string& symbol) const;
    
    // Market data handling
    void handleMarketData(const omni_message* msg);
    void handleTradingStatus(const omni_message* msg);
    void handleReferenceData(const omni_message* msg);
    
    // Market data retrieval
    MarketData getMarketData(const std::string& symbol) const;
    std::vector<std::string> getSubscribedSymbols() const;
    
    // Callback registration
    using MarketDataCallback = std::function<void(const MarketData&)>;
    using StatusCallback = std::function<void(const std::string&, const std::string&)>;
    void registerMarketDataCallback(MarketDataCallback callback);
    void registerStatusCallback(StatusCallback callback);

private:
    // Helper functions
    void processMarketData(const omni_message* msg);
    void notifyMarketDataCallbacks(const MarketData& data);
    void notifyStatusCallbacks(const std::string& symbol, const std::string& status);

    // Market data storage
    std::unordered_map<std::string, std::shared_ptr<MarketData> > market_data_;
    std::unordered_set<std::string> subscribed_symbols_;
    
    // Callbacks
    std::vector<MarketDataCallback> market_data_callbacks_;
    std::vector<StatusCallback> status_callbacks_;
    
    // Thread safety
    mutable std::mutex market_data_mutex_;
    mutable std::mutex callback_mutex_;
}; 