#pragma once

#include <string>
#include "omniapi.h"
#include "Logger.hpp"
#include "ErrorHandler.hpp"

class SessionHandler {
public:
    static SessionHandler& getInstance();

    bool initialize(const std::string& host, int port);
    bool login(const std::string& username, const std::string& password);
    bool logout();
    bool isConnected() const;
    
    // Get the OMnet API session handle
    omniapi_session_t getSession() const { return session; }

private:
    SessionHandler() = default;
    ~SessionHandler();
    
    SessionHandler(const SessionHandler&) = delete;
    SessionHandler& operator=(const SessionHandler&) = delete;

    bool createSession();
    void closeSession();
    
    omniapi_session_t session;
    bool connected;
    
    std::string host;
    int port;
    std::string username;
}; 