#pragma once

#include <string>
#include <stdexcept>
#include "Logger.hpp"

class OMnetError : public std::runtime_error {
public:
    explicit OMnetError(const std::string& message) : std::runtime_error(message) {}
};

class ErrorHandler {
public:
    static ErrorHandler& getInstance();

    void handleError(int errorCode, const std::string& context);
    void handleOMnetError(int omnetReturnCode, const std::string& context);
    
    // Common OMnet API error codes
    static const int OMNIAPI_SUCCESS = 0;
    static const int OMNIAPI_NOT_FOUND = -1;
    static const int OMNIAPI_INVALID_SESSION = -2;
    static const int OMNIAPI_CONNECTION_ERROR = -3;

private:
    ErrorHandler() = default;
    ~ErrorHandler() = default;
    
    ErrorHandler(const ErrorHandler&) = delete;
    ErrorHandler& operator=(const ErrorHandler&) = delete;

    std::string getErrorMessage(int errorCode);
    void logError(const std::string& message);
}; 