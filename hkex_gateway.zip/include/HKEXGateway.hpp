#pragma once

#include <string>
#include <memory>
#include <functional>
#include <thread>
#include "SessionHandler.hpp"
#include "OrderManager.hpp"
#include "MarketDataHandler.hpp"
#include "TradeManager.hpp"
#include "Logger.hpp"
#include "ErrorHandler.hpp"

class HKEXGateway {
public:
    static HKEXGateway& getInstance();

    // Initialization
    bool initialize(const std::string& config_file);
    bool start();
    bool stop();
    
    // Connection management
    bool connect(const std::string& host, int port,
                const std::string& username, const std::string& password);
    bool disconnect();
    bool isConnected() const;
    
    // Order operations
    bool submitOrder(const OrderDetails& order, std::string& orderId);
    bool modifyOrder(const std::string& orderId, const OrderDetails& newDetails);
    bool cancelOrder(const std::string& orderId);
    bool getOrderStatus(const std::string& orderId, OrderDetails& details);
    
    // Market data operations
    bool subscribeMarketData(const std::string& symbol);
    bool unsubscribeMarketData(const std::string& symbol);
    bool getMarketData(const std::string& symbol, MarketData& data);
    
    // Trade operations
    bool getTrade(const std::string& tradeId, TradeDetails& trade);
    std::vector<TradeDetails> getTradesByOrder(const std::string& orderId);
    
    // Event callbacks
    void setOrderStatusCallback(std::function<void(const OrderDetails&)> callback);
    void setTradeCallback(std::function<void(const TradeDetails&)> callback);
    void setMarketDataCallback(std::function<void(const MarketData&)> callback);

private:
    HKEXGateway() = default;
    ~HKEXGateway();
    
    HKEXGateway(const HKEXGateway&) = delete;
    HKEXGateway& operator=(const HKEXGateway&) = delete;

    // Helper functions
    bool loadConfig(const std::string& config_file);
    void processMessages();
    void handleError(const std::string& context, int error_code);
    
    // Callback storage
    std::function<void(const OrderDetails&)> orderCallback;
    std::function<void(const TradeDetails&)> tradeCallback;
    std::function<void(const MarketData&)> marketDataCallback;
    
    // Thread control
    bool running;
    std::unique_ptr<std::thread> messageThread;
}; 