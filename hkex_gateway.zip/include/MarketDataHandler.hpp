#pragma once

#include <string>
#include <functional>
#include <map>
#include "SessionHandler.hpp"
#include "Logger.hpp"
#include "ErrorHandler.hpp"

struct MarketData {
    std::string symbol;
    double lastPrice;
    int lastQuantity;
    double bid;
    double ask;
    int bidSize;
    int askSize;
    std::string timestamp;
};

class MarketDataHandler {
public:
    static MarketDataHandler& getInstance();

    // Market data subscription
    bool subscribeSymbol(const std::string& symbol);
    bool unsubscribeSymbol(const std::string& symbol);
    
    // Callback registration
    using MarketDataCallback = std::function<void(const MarketData&)>;
    void registerCallback(const std::string& symbol, MarketDataCallback callback);
    
    // Process incoming market data
    void processMarketData(const std::string& message);
    
    // Get latest market data
    bool getLastMarketData(const std::string& symbol, MarketData& data);

private:
    MarketDataHandler() = default;
    ~MarketDataHandler() = default;
    
    MarketDataHandler(const MarketDataHandler&) = delete;
    MarketDataHandler& operator=(const MarketDataHandler&) = delete;

    // Helper functions
    bool parseMarketData(const std::string& message, MarketData& data);
    void notifySubscribers(const MarketData& data);
    
    // Storage
    std::map<std::string, MarketData> latestData;
    std::map<std::string, MarketDataCallback> callbacks;
}; 