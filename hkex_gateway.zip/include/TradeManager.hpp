#pragma once

#include <string>
#include <map>
#include <vector>
#include "SessionHandler.hpp"
#include "Logger.hpp"
#include "ErrorHandler.hpp"

struct TradeDetails {
    std::string tradeId;
    std::string orderId;
    std::string symbol;
    std::string side;
    double price;
    int quantity;
    std::string timestamp;
    std::string status;  // "FILLED", "PARTIALLY_FILLED", etc.
};

class TradeManager {
public:
    static TradeManager& getInstance();

    // Trade management
    void processTrade(const TradeDetails& trade);
    bool getTrade(const std::string& tradeId, TradeDetails& trade);
    std::vector<TradeDetails> getTradesByOrder(const std::string& orderId);
    
    // Trade updates
    void updateTradeStatus(const std::string& tradeId, const std::string& status);
    
    // Trade history
    std::vector<TradeDetails> getTradeHistory(const std::string& symbol, 
                                            const std::string& startTime,
                                            const std::string& endTime);

private:
    TradeManager() = default;
    ~TradeManager() = default;
    
    TradeManager(const TradeManager&) = delete;
    TradeManager& operator=(const TradeManager&) = delete;

    // Helper functions
    void logTrade(const TradeDetails& trade);
    void notifyTradeUpdate(const TradeDetails& trade);
    
    // Storage
    std::map<std::string, TradeDetails> trades;  // tradeId -> TradeDetails
    std::map<std::string, std::vector<std::string> > orderTrades;  // orderId -> vector<tradeId>
}; 